
/* Embed a copyright string */
static char __copyright__[] = "Copyright 2005 Graeme W. Gill";


