
#ifndef __CONFIG_H__
#define __CONFIG_H__

/* General project wide configuration */


/* Version of Argyll release */

#define ARGYLL_VERSION 0x000503
#define ARGYLL_VERSION_STR "0.53"

/* Maximum file path length */
#define MAXNAMEL 512

#endif /* __CONFIG_H__ */
